// index.js
// ------------------------------------------------------------------
//
// created: Tue Nov 17 14:40:14 2020
// last saved: <2020-November-17 14:41:23>

/* jshint esversion:9, node:true, strict:implied */
/* global process, console, Buffer */

module.exports = {
  bundleLinter : require('./lib/package/bundleLinter.js')
};
