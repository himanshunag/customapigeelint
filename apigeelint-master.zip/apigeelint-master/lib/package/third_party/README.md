These files were copied from the [eslint](https://github.com/eslint/eslint) project.
