
const ruleId = require("../lib/package/myUtil").getRuleId(),
    debug = require("debug")("apigeelint:" + ruleId);

const plugin = {
    ruleId,
    name: "proxyConfig properties",
    message: "Check basic proxy config properties",
    fatal: false,
    severity: 2, //error
    nodeType: "Resource",
    enabled: true
};

let hadWarnErr = false;

const onBundle = function (bundle, cb) {
    try {
        function setMessage(source) {
            // console.log("source : " + source);
            bundle.addMessage({
                plugin,
                message: source
            });
            hadWarnErr = true;
        }
        if (bundle.profile) { bundleProfile = bundle.profile; }
        if (bundleProfile === "apigeex") {
            let resources = bundle.getResources();
            resources.forEach(function (resource) {
                let fname = resource.getFileName();
                // console.log("fname : " + fname);
                if (fname.endsWith(".properties")) {
                    // console.log("content : " + resource.getContents());
                    var fileContent = resource.getContents();
                    if (fileContent.length > 0) {
                        let jwtFlag, oidc, dpopFlag, authFlag, loggingFlag;
                        fileContent.split(/\r?\n/).forEach(item => {
                            var key = item.split("=")[0].trim();
                            var value = item.split("=")[1].trim();
                            // console.log("key : " + key);
                            // console.log("value : " + value);
                            if (key === "jwtFlag") jwtFlag = value;
                            if (key === "oidc") oidc = value;
                            if (key === "dpopFlag") dpopFlag = value;
                            if (key === "authFlag") authFlag = value;
                            if (key === "logging") loggingFlag = value;
                        });
                        // console.log("Flag status : " + jwtFlag, oidc, dpopFlag, authFlag, corsFlag, faultHandleFlag)
                        if (jwtFlag === "false" && oidc === "false" && dpopFlag === "false" && authFlag === "false") {
                            setMessage("Proxy must be secured with at least one security mechanism.");
                        }
                        if (loggingFlag === "false") {
                            setMessage("logging must be enabled for the proxy.");
                        }
                    } else {
                        setMessage("No content in proxy configuration properties file.");
                    }
                }
            });
        }
    } catch (e) {
        debugger;
        debug("proxyconfig error" + e);
    }
    if (typeof cb == "function") {
        cb(null, hadWarnErr);
    }
};

module.exports = {
    plugin,
    onBundle
};