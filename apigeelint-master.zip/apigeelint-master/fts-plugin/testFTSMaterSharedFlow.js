const assert = require("assert"),
    path = require("path"),
    Bundle = require("../lib/package/Bundle.js"),
    bl = require("../lib/package/bundleLinter.js");

const configuration = {
    debug: true,
    source: {
        type: "filesystem",
        path: path.resolve(__dirname, '../test/fixtures/resources/BN011-master-sharedflow-endpoint/apiproxy'),
        bundleType: "apiproxy"
    },
    profile: 'apigeex',
    excluded: {},
    setExitCode: false,
    output: () => { } // suppress output
};

describe("Check FTS master sharedflow's flowcallout policy", function () {
    var pluginFile = path.resolve(__dirname, "EX-BN011-checkMasterSharedFlow.js"),
        ruleId = "BN011";

    it("should show error when master sharedflow is not attached to all the required flows", function () {
        var bundle = new Bundle(configuration);
        bl.executePlugin(pluginFile, bundle);
        var report = getReportByRuleId(ruleId, bundle.getReport());
        assert.equal(report[0].message, "FlowCallout policy is not attched at all the required points in API proxy.");
        assert.equal(report[0].severity, 2);
    });

    it("should show error when master sharedflow is not enabled", function () {
        var enableConfiguration = configuration;
        enableConfiguration.source.path = path.resolve(__dirname, '../test/fixtures/resources/BN011-master-sharedflow-enable-check/apiproxy')
        var bundle = new Bundle(enableConfiguration);
        bl.executePlugin(pluginFile, bundle);
        var report = getReportByRuleId(ruleId, bundle.getReport());
        assert.equal(report[0].message, "FlowCallout policy invoking FTS master sharedflow is not enabled.");
        assert.equal(report[0].severity, 2);
    });

});

function getReportByRuleId(ruleId, bundleReport) {
    var jsimpl = bl.getFormatter("json.js"),
        jsonReport = JSON.parse(jsimpl(bundleReport)),
        reports = [];

    for (let r of jsonReport) {
        for (let m of r.messages) {
            if (m.ruleId === ruleId) {
                reports.push(m);
            }
        }
    }
    return reports;
}
