// EX-PO034-checkProxyConfig.js
// ------------------------------------------------------------------

const assert = require("assert"),
    path = require("path"),
    Bundle = require("../lib/package/Bundle.js"),
    bl = require("../lib/package/bundleLinter.js");

describe(`PO034 - Check the proxy configuration properties`, () => {

    var pluginFile = path.resolve(__dirname, "EX-PO035-checkKVMConfigForSaas.js"),
        ruleId = "PO035";
    var configuration = {
        debug: true,
        source: {
            type: "filesystem",
            path: path.resolve(__dirname, '../test/fixtures/resources/PO035-CheckSaasConfigProperties'),
        },
        excluded: {},
        // profile: 'apigee',
        setExitCode: false,
        output: () => { } // suppress output
    };
    var bundle = new Bundle(configuration);
    bl.executePlugin(pluginFile, bundle);
    it("Check basic proxy config properties ", function () {
        let report = bundle.getReport();
        // console.log("report is done", report[0].messages[1]);
        assert.equal(report[0].messages[1].message, "Proxy must be secured with at least one security mechanism.");
        assert.equal(report[0].messages[1].severity, 2);
    }
    );
});