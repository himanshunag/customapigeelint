/*
  Copyright 2019-2021 Google LLC

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

const ruleId = require("../lib/package/myUtil.js").getRuleId(),
    xpath = require("xpath"),
    debug = require("debug")("apigeelint:" + ruleId);

const plugin = {
    ruleId,
    name: "Check class name format of the jar file used in javaCallout policy.",
    message:
        "It is recommended that the javaCallout policy class name should have com.fiserv.* format",
    fatal: false,
    severity: 1, //warning
    nodeType: "Policy",
    enabled: true
};

const onPolicy = function (policy, cb) {
    let hadWarnErr = false;
    function setMessage(source) {
        // console.log("source : " + source);
        policy.addMessage({
            plugin,
            message: source
        });
        hadWarnErr = true;
    }
    // console.log("Custom plugin executing....");
    let policyType = policy.getType();
    let regClassName = new RegExp("com.fiserv.*");

    if (policyType === "JavaCallout") {
        var className = xpath.select("//JavaCallout/ClassName/text()", policy.getElement());
        // console.log("className : " + className);
        if (!regClassName.test(className)) {
            setMessage('JavaCallout policy does not have classname in FTS format, e.g. com.fiserv.*');
        }
        if (typeof cb == "function") {
            cb(null, hadWarnErr);
        }
    }
};

module.exports = {
    plugin,
    onPolicy
};
