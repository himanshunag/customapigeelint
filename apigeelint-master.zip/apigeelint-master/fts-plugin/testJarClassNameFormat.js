// EX-PO033-checkJarFileClassNameFormat.js
// ------------------------------------------------------------------

const assert = require("assert"),
      fs = require("fs"),
      path = require("path"),
      plugin = require("./EX-PO033-checkJarFileClassNameFormat.js"),
      Policy = require("../lib/package/Policy.js"),
      Dom = require("@xmldom/xmldom").DOMParser;

const test =
  (filename, cb) => {
    it(`should correctly process ${filename}`, () => {
        console.log("filename" + filename);
      let fqfname = path.resolve(__dirname, '../test/fixtures/resources/PO033-CheckJarClassNameFormat', filename),
          policyXml = fs.readFileSync(fqfname, 'utf-8'),
          doc = new Dom().parseFromString(policyXml),
          p = new Policy(doc.documentElement, this);

      p.getElement = () => doc.documentElement;

      plugin.onPolicy(p, (e, foundIssues) => {
        assert.equal(e, undefined, "should be undefined");
        cb(p, foundIssues);
      });
    });
  };

describe(`PO033 - Check class name format of the jar file`, () => {

  test('JC-FTS-JavaCallout-fail.xml', (p, foundIssues) => {
    assert.equal(foundIssues, true);
    // console.log("report : " + JSON.stringify(p.getReport()));
    assert.ok(p.getReport().messages, "JavaCallout policy does not have classname in FTS format, e.g. com.fiserv.*");
    assert.equal(p.getReport().messages.length, 1, JSON.stringify(p.getReport().messages));
  });

  test('JC-FTS-JavaCallout-success.xml', (p, foundIssues) => {
    assert.equal(foundIssues, false);
    assert.ok(p.getReport().messages, "JavaCallout policy have classname in FTS format.");
    assert.equal(p.getReport().messages.length, 0, JSON.stringify(p.getReport().messages));
  });

});
