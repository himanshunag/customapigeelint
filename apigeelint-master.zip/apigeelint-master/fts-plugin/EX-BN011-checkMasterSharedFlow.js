/*
  Copyright 2019-2020 Google LLC

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

const myUtil = require("../lib/package/myUtil.js"),
  xpath = require("xpath"),
  ruleId = myUtil.getRuleId(),
  debug = require("debug")("apigeelint:" + ruleId);

const plugin = {
  ruleId,
  name: "Check FlowCallout for master SharedFlow",
  message:
    "It is mandatory to include the FTS master shared flow in very proxy.",
  fatal: false,
  severity: 2, //error
  nodeType: "Bundle",
  enabled: true
};

let hadWarnErr = false;

const onBundle = function (bundle, cb) {
  function setMessage(source) {
    // console.log("source : " + source);
    bundle.addMessage({
      plugin,
      message: source
    });
    hadWarnErr = true;
  }
  // console.log("Custom plugin executing....");
  // Is there a flowcallout policy?
  // Does any flowcallout policy calls into master SF?
  // Is this flowcallout policy attached?
  let masterSFFlag = false;
  bundle.getPolicies().forEach(function (policy) {
    // console.log("plugin : " + plugin.ruleId);
    // debug(`boundaries.length(${policy})`);
    // console.log("policy Type() : " + policy.getType());
    if (policy.getType() === "FlowCallout") {
      // console.log("Flowcallout policy found");
      var shardedFlowName = xpath.select("//FlowCallout/SharedFlowBundle/text()", policy.getElement());
      // console.log("shardedFlowName : " + shardedFlowName);
      if (shardedFlowName == "SF-FTS-APIM-MASTER_CONFIGURATION-V2") {
        masterSFFlag = true;
        if (policy.getSteps().length > 0) {
          var stepFlowFlag = 0;
          policy.getSteps().forEach(function (step) {
            // console.log("Flowcallout policy steps " + step.getFlowName());
            var completeFlowName = step.getFlowName().split("#")[1];
            var proxyPreFlowRequest = "document:ProxyEndpoint:PreFlow:Request:" + policy.getName()
            var proxyPostFlowResponse = "document:ProxyEndpoint:PostFlow:Response:" + policy.getName()
            var proxyDefaultFaultRule = "document:ProxyEndpoint:DefaultFaultRule:" + policy.getName()
            var targetPreFlowRequest = "document:TargetEndpoint:PreFlow:Request:" + policy.getName()
            var targetPostFlowResponse = "document:TargetEndpoint:PostFlow:Response:" + policy.getName()
            if (completeFlowName === proxyPreFlowRequest || completeFlowName === proxyPostFlowResponse || completeFlowName === proxyDefaultFaultRule || completeFlowName === targetPreFlowRequest || completeFlowName === targetPostFlowResponse) {
              // console.log("Checking step flow name");
              stepFlowFlag++;
            }
          });
          // console.log("stepFlowFlag : " + stepFlowFlag);
          if (stepFlowFlag < 5) {
            // console.log("FlowCallout policy is not attched in preflow request");
            // flowcallout policy invoking master shared not attched in preflow request of proxyEndpoint
            setMessage('FlowCallout policy is not attched at all the required points in API proxy.');
          }
          // console.log("check enabled " + !(policy.select("/FlowCallout/@enabled") === 'enabled="true"'));
          if (!(policy.select("/FlowCallout/@enabled") === 'enabled="true"')) {
            // console.log("Checking enabled attribute");
            // flowcallout policy invoking master shared is not enabled
            setMessage('FlowCallout policy invoking FTS master sharedflow is not enabled.');
          }
        } else {
          // console.log("policy is found but never used");
          // flowcallout policy invoking master shared is not attched
          setMessage('FlowCallout policy is not attched.');
        }
      }
    }
  });
  if (!masterSFFlag) {
    console.log("No flowCallout policy found for FTS Master SF");
    // No policy exists for master Sharedflow
    setMessage('No flowCallout policy exist for FTS master sharedflow.');
  }
  if (typeof (cb) == 'function') {
    cb(null, hadWarnErr);
  }
};

module.exports = {
  plugin,
  onBundle,
};
