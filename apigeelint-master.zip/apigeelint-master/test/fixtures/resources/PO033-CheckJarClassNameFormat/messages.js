// These are the error messages only for the failed policies.
module.exports = {
  "MyJavaCalloutPolicyFail" : "JavaCallout policy does not have classname in FTS format, e.g. com.fiserv.*",
  "MyJavaCalloutPolicySuccess" : "JavaCallout policy have classname in FTS format."
};
